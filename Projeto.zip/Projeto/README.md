# Novos Tópicos no trabalho entregue a 01/02/2022 em relação ao trabalho apresentado em 31/02/2022

Adicionámos uma secção com as tabelas anuais das classificações de pilotos e construtores. 
Logo utilizámos outra api: GET api/Statistics/Season?year={year}



# Tópicos do trabalho na versão do dia da apresentação - 31/01/2022

Página principal -
Navbar com secções da página e search All (este search leva para uma página com um gráfico Google Piechart que divido os diversos resultados em drivers,constructors,circuits and races)
carrossel
texto
footer que possui links para as páginas oficiais
hidden links para acessibilidade de teclado (Skip navigation - skip carosel - skip footer)
Na navbar tem a opção de escolher o icone com um calendário - abre um datepicker (jquery ui) que tem as datas de races favoritas marcadas. Ao clicar nessa data leva para a corrida em questão

Drivers -
search Drivers
Informações da página e paginação
tabela com botões para selecionar favoritos e para ir para os driver details
filtro:
para escolher nacionalidade - (carrega as nacionalidades através da api)
para fazer sort por id e nationalidade

Champions Drivers -
Navtab dividido por décadas
Cards com foto e informações de piloto e link para o seu driver profile (dados da api)

Champions Constructors - semelhante ao "Champions Drivers" só que os links é para o team profile/team details

Circuits -
Mapa leaflet com localizações de todos os circuitos marcadas (com os dados da api) e com borders definidas
cada um dos markers tem um popup com um link para Circuit details

Races List - Página semelhante à dos drivers só que sem filtros (tmb tem favoritos, details e search)

Teams - página semelhante à dos champions com a diferença de poder escolher teams favoritas e do search ter autocomplete (também têm link para os team profiles)

About us - Informações sobre nós, sobre as API's utilizadas, sobre as ferramentas de bootstrap utilizadas e com um modal com validação de formulário

Favorites - tem os drivers, teams e races favoritas com respetivos links, usando LocalStorage

Driver Details, Team Details e race details - details dos drivers, das teams/constructors e das races(que para além de details têm links para os drivers e constructors que participaram na corrida)

Qualquer search se não encontrar resultados aparence "No results founded" (no caso do search all aparece ' 0 Results for " " ')

Todo o site encontra-se responsivo (através da utilização de containers bootstrap)
